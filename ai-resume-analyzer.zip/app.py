import streamlit as st
import PyPDF2
import re
from collections import Counter

# --- Load skill keywords ---
with open("model/skills.txt", "r") as f:
    skills_list = [line.strip().lower() for line in f.readlines()]

# --- Streamlit App ---
st.set_page_config(page_title="AI Resume Analyzer", page_icon="🤖")
st.title("🤖 AI Resume Analyzer")
st.write("Upload your resume (PDF) and let AI analyze it!")

uploaded_file = st.file_uploader("Upload Resume (PDF)", type=["pdf"])

if uploaded_file is not None:
    pdf_reader = PyPDF2.PdfReader(uploaded_file)
    resume_text = ""
    for page in pdf_reader.pages:
        resume_text += page.extract_text()

    st.subheader("📄 Extracted Resume Text:")
    st.write(resume_text[:1000] + "..." if len(resume_text) > 1000 else resume_text)

    # --- Skill Extraction ---
    found_skills = [skill for skill in skills_list if re.search(r"\b" + re.escape(skill) + r"\b", resume_text.lower())]

    st.subheader("🧠 Extracted Skills:")
    st.write(", ".join(set(found_skills)) if found_skills else "No common skills found.")

    # --- ATS Score ---
    ats_score = round((len(found_skills) / len(skills_list)) * 100, 2)
    st.subheader("📊 ATS Score:")
    st.progress(int(ats_score))
    st.write(f"**Your ATS Score:** {ats_score}%")

    # --- Simple Recommendation ---
    if "machine learning" in found_skills or "data science" in found_skills:
        st.info("💼 Suggested Role: Data Scientist / ML Engineer")
    elif "web development" in found_skills:
        st.info("💼 Suggested Role: Web Developer")
    elif "python" in found_skills:
        st.info("💼 Suggested Role: Python Developer")
    else:
        st.info("💼 Suggested Role: Software Engineer")

    st.success("✅ Resume Analysis Complete!")
