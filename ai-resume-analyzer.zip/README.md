# 🤖 AI Resume Analyzer

An AI-powered web app that analyzes resumes, extracts skills, and calculates an ATS (Applicant Tracking System) score.

## 🚀 Features
- Upload your resume in PDF format
- Extracts skills using NLP pattern matching
- Calculates ATS score based on found skills
- Suggests suitable job roles
- Built using **Python + Streamlit**

## 🧠 Tech Stack
- Python  
- Streamlit  
- PyPDF2  
- Regular Expressions  

## ⚙️ Setup Instructions
1️⃣ Clone the repository:
```bash
git clone https://github.com/yourusername/ai-resume-analyzer.git
cd ai-resume-analyzer
```

2️⃣ Install dependencies:
```bash
pip install -r requirements.txt
```

3️⃣ Run the app:
```bash
streamlit run app.py
```

4️⃣ Upload your resume (PDF) and view the results!

## ✨ Author
**Chandu Charan Srikanth**
🎓 B.Tech CSE (AI & ML), SRK Institute of Technology
💻 GitHub: [yourusername](https://github.com/yourusername)
